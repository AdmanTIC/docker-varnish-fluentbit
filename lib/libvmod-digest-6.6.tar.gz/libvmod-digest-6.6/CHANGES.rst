This is a running log of changes to libvmod-digest.

libvmod-digest 1.0.2 (2017-03-07)
---------------------------------

* Small docs and compilation fixes.

* Added compatibility with Varnish Cache 6.0

This release was tested with Varnish Cache 4.1.9 and trunk (2018-03-07)


libvmod-digest 1.0.1 (2016-03-15)
---------------------------------

Changes since 1.0.0:

* Fix overread in base64_encode()
* is_hex() stylistic cleanups.

This release was tested with Varnish Cache 4.1.2.


libvmod-digest 1.0.0 (2016-03-14)
---------------------------------

This is libvmod-digest, allowing use of libmhash (cryptographic functions)
in Varnish VCL.

Changes since last release:

* Semantic versioning introduced.

* Packaging files moved out of tree.

This release was tested with Varnish Cache 4.1.2.

List of changes was not kept for previous versions.
